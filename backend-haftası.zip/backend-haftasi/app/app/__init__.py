# app/app/__init__.py
from flask import Flask
from app.config import Config
from .database import db, init_db

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    db.init_app(app)
    with app.app_context():
        init_db()

    from .api import api_bp
    app.register_blueprint(api_bp)

    # NOT: Burada Celery ile bağ kurmuyoruz. Celery ayrı modülde ayakta.
    return app

app = create_app()
