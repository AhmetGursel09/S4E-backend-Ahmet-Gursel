from flask import Flask
from app.config import Config
from .database import db, init_db

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    db.init_app(app)
    with app.app_context():
        init_db()  # tabloları oluştur

    from .api import api_bp
    app.register_blueprint(api_bp)

    return app

# flask run'ın görebilmesi için:
app = create_app()
